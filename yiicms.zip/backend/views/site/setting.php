<?php


/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model \common\models\LoginForm */

$this->title = '系统设置';
$this->params['breadcrumbs'][] = $this->title;
?>