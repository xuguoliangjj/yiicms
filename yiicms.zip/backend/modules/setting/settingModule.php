<?php

namespace backend\modules\setting;

class settingModule extends \yii\base\Module
{
    public $controllerNamespace = 'backend\modules\setting\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
