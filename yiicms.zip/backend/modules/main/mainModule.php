<?php

namespace backend\modules\main;

class mainModule extends \yii\base\Module
{
    public $controllerNamespace = 'backend\modules\main\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
